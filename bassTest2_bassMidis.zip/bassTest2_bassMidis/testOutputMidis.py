#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 21 17:29:18 2018

@author: adamsmoulder
"""

# THIS FUNCTION DOES NOT YET WORK WITH MULTIINSTRUMENT SETUP!
def matrix_to_midi(matrix, instName):
    first_touch = 1.0
    continuation = 0.0
    y_axis, x_axis = matrix.shape
    output_notes = []
    offset = 0
            
    matrix = matrix.astype(float)
    
    print (y_axis, x_axis)  # ADAM YOU'RE HERE debugging why the output fails

    for y_axis_num in range(y_axis):
        one_freq_interval = matrix[y_axis_num,:] # get a column
        # freq_val = 0 # columdaki hangi rowa baktığımızı akılda tutmak için
        one_freq_interval_norm = converter_func(one_freq_interval)
        # print (one_freq_interval)
        i = 0        
        offset = 0
        while (i < len(one_freq_interval)):
            how_many_repetitive = 0
            temp_i = i
            if (one_freq_interval_norm[i] == first_touch):
                how_many_repetitive = how_many_repetitive_func(one_freq_interval_norm, from_where=i+1, continuation=continuation)
                i += how_many_repetitive 
#            try:
#                print(how_many_repetitive)
#                (how_many_repetitive > 0)
#            except ValueError as ex:
#                print(how_many_repetitive)
            
            if (how_many_repetitive > 0):
                new_note = note.Note(int_to_note(y_axis_num),duration=duration.Duration(0.25*how_many_repetitive))
                new_note.offset = 0.25*temp_i
                if instName is "Bass":
                    new_note.storedInstrument = instrument.Bass()
                elif instName is "Guitar":
                    new_note.storedInstrument = instrument.Guitar()
                elif instName is "Drums":
                    new_note.storedInstrument = instrument.ElectricOrgan() # THIS IS HACKISH!!!
                else:
                    new_note.storedInstrument = instrument.Piano()
                output_notes.append(new_note)
            else:
                i += 1
    return output_notes



# Run it here
if len(wantedInstruments) > 1:
    for inst in wantedInstruments:
        for i in range(len(midis_array_original)): # for each song:
            thePart = matrix_to_midi(midis_array_original[i,wantedInstruments.index(inst),:,:],inst)
            midi_stream = stream.Stream(thePart)
            songname = all_midi_paths[i].split("/",3)[2:4]
            output_filename = wantedInstruments[0] + '_' + songname[0] + '_' + songname[1]
            midi_stream.write('midi', fp=output_filename)
            print("finished " + str(i) + " of " + str(len(midis_array_original)))
            
else:
    for i in range(len(midis_array_original)): # for each song:
        thePart = matrix_to_midi(midis_array_original[i,:,:],wantedInstruments[0])
        midi_stream = stream.Stream(thePart)
        songname = all_midi_paths[i].split("/",3)[2:4]
        output_filename = wantedInstruments[0] + '_' + songname[0] + '_' + songname[1]
        midi_stream.write('midi', fp=output_filename)
        print("finished " + str(i) + " of " + str(len(midis_array_original)))
    